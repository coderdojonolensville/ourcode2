#Not equal operator example
if('goodbye' != 'hello'):
    print('not equal')
    
#Less than operator example
if(0 < 6):
    print('Nope, zero is less than 6')

#Greater than operator example
if(50 < 100):
    print('Hey Sonny Jim, 50 is less than 100')          

#Equality Operator example
if('Hello'=='Hello'):
    print("Yep, Hello and Hello are equal")


#InEquality Operator example
if('Hello'!='HELLO'):
    print('That's a fact Jack hello and HELLO are not equal')


    
#Greater than or equal to example
yourAge=23

if(yourage >= 18):
    print('You can vote!')

#Less than or equal to example
yourAge=13

if(yourAge <= 15):
    print('Too young to drive')


#Concantenation Example
greeting='hello'
length=len(greeting)
print(greeting + ' has ' + str(length) + ' characters')
